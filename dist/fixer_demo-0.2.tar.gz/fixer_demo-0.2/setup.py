

from setuptools import setup
 
 
setup(name='fixer-demo',
      version='0.2',
      url="https://github.com/leilawe/fexerdemo",
      install_requires=['requests'],
      packages=['fixer'],
 )
