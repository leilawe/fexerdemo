

from setuptools import setup
 
 
setup(name='fixer-demo',
      version='0.1',
      packages=['fixer'],
 )
